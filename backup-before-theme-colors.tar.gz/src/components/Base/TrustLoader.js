"use client";
// Keeps the trust details (Settings → Trust Details) loaded and up to date for
// the whole panel. Renders nothing.
//
//   1. Instantly: last known values from this browser (localStorage)
//   2. Public API (/api/trust-info) — works on the login page, before sign-in
//   3. Once signed in: a live Firestore listener, so a change saved in the
//      settings form shows up everywhere straight away, in every open tab.
import { useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../../lib/firbase-client';
import { useAuth } from './AuthProvider';
import { setTrustInfo } from '@/Redux/Slice/commonSlice';
import {
  TRUST_DOC_PATH,
  getTrust,
  getTrustRaw,
  setTrust,
  subscribeTrust,
  hydrateTrustFromCache,
} from '@/utils/trust/trustStore';

// Browser-tab icon: once a logo has been uploaded, use it instead of the
// built-in favicon.
const applyFavicon = (href) => {
  if (typeof document === 'undefined' || !href) return;
  let links = Array.from(document.querySelectorAll("link[rel~='icon']"));
  if (!links.length) {
    const link = document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
    links = [link];
  }
  links.forEach((link) => {
    if (link.getAttribute('href') === href) return;
    link.removeAttribute('sizes');
    link.removeAttribute('type');
    link.setAttribute('href', href);
  });
};

export default function TrustLoader() {
  const { user } = useAuth() || {};
  const dispatch = useDispatch();
  const gotLiveData = useRef(false);

  // Mirror into Redux (state.data.trustInfo), the browser tab title and tab icon
  useEffect(() => {
    const sync = () => {
      const trust = getTrust();
      dispatch(setTrustInfo({ ...getTrustRaw() }));
      if (typeof document !== 'undefined' && trust.panelTitle) document.title = trust.panelTitle;
      if (trust.hasCustomLogo) applyFavicon(trust.logoSrc);
    };
    const unsubscribe = subscribeTrust(sync);
    sync();
    return unsubscribe;
  }, [dispatch]);

  // Cache first, then the public API
  useEffect(() => {
    let cancelled = false;
    hydrateTrustFromCache();
    fetch('/api/trust-info')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (cancelled || gotLiveData.current || !data?.success) return;
        setTrust(data.trust || {});
      })
      .catch(() => { /* offline — cached/default values stay */ });
    return () => { cancelled = true; };
  }, []);

  // Live updates while signed in
  useEffect(() => {
    if (!user?.uid) return undefined;
    const unsubscribe = onSnapshot(
      doc(db, ...TRUST_DOC_PATH),
      (snap) => {
        gotLiveData.current = true;
        setTrust(snap.exists() ? snap.data() : {});
      },
      (err) => console.warn('Trust details listener:', err?.code || err),
    );
    return unsubscribe;
  }, [user?.uid]);

  return null;
}
